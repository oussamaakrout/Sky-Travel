#include<stdio.h>
#include<stdlib.h>
#include "verification.h"
#include<string.h>

int verification(char username[],char mot_de_passe[])
{
FILE *f;
char user[30];
char mdp[30];
int role;
f=fopen("users.txt","r");
        if (f!=NULL)
{
             while(fscanf(f,"%s %s %d \n",user,mdp,&role)!=EOF)  
{
if ((strcmp(username,user)==0)&&(strcmp(mot_de_passe,mdp)==0))
break;
else role=0;
}
}  
fclose(f);    
         
return(role);
     
 }
