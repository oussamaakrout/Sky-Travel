#include <stdlib.h>
#include <string.h>

int verification(char username[],char mot_de_passe[]);

