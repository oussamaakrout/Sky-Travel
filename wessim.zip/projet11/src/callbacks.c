#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "agents.h"

void
on_Valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *input3;
GtkWidget *input4;
GtkWidget *input5;
GtkWidget *input6;
GtkWidget *input7;
GtkWidget *input8;
GtkWidget *fenetre_ajouter;

agent a;

input1=lookup_widget(objet,"id");
strcpy(a.id,gtk_entry_get_text(GTK_ENTRY(input1)));

input2=lookup_widget(objet,"nom");
strcpy(a.nom,gtk_entry_get_text(GTK_ENTRY(input2)));

input3=lookup_widget(objet,"prenom");
strcpy(a.prenom,gtk_entry_get_text(GTK_ENTRY(input3)));

input4=lookup_widget(objet,"date_de_naissance");
strcpy(a.date_de_naissance,gtk_entry_get_text(GTK_ENTRY(input4)));

input5=lookup_widget(objet,"cin");
strcpy(a.cin,gtk_entry_get_text(GTK_ENTRY(input5)));

input6=lookup_widget(objet,"genre");
strcpy(a.genre,gtk_entry_get_text(GTK_ENTRY(input6)));

input7=lookup_widget(objet,"telephone");
strcpy(a.telephone,gtk_entry_get_text(GTK_ENTRY(input7)));

input8=lookup_widget(objet,"email");
strcpy(a.email,gtk_entry_get_text(GTK_ENTRY(input8)));


ajouter_agent(a);


}



void
on_Afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter;
GtkWidget *fenetre_afficher;
GtkWidget *treeview1;

fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
gtk_widget_destroy(fenetre_ajouter);
fenetre_afficher=create_fenetre_afficher();
gtk_widget_show(fenetre_afficher);

treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_agent(treeview1);

}


void
on_Retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajouter;
GtkWidget *fenetre_afficher;
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
fenetre_ajouter=lookup_widget(objet,"fenetre_ajouter");
gtk_widget_destroy(fenetre_afficher);
fenetre_ajouter=create_fenetre_ajouter();
gtk_widget_show(fenetre_ajouter);
}


void
on_Supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_afficher;
GtkWidget *supprimer_agent;
fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
supprimer_agent=lookup_widget(objet,"supprimer_agent");
gtk_widget_destroy(fenetre_afficher);
supprimer_agent=create_supprimer_agent();
gtk_widget_show(supprimer_agent);
}


void
on_Confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1,*supprimer_agent;
char s[30];

supprimer_agent=lookup_widget(objet,"supprimer_agent");

input1=lookup_widget(objet,"entry120");
strcpy(s,gtk_entry_get_text(GTK_ENTRY(input1)));
Supprimer_vol( "agents.txt",s);


GtkWidget *fenetre_afficher;
GtkWidget *treeview1;



fenetre_afficher=lookup_widget(objet,"fenetre_afficher");
fenetre_afficher=create_fenetre_afficher();
gtk_widget_destroy(supprimer_agent);
gtk_widget_show(fenetre_afficher);

treeview1=lookup_widget(fenetre_afficher,"treeview1");
afficher_agent(treeview1);
}


void
on_Modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

}

