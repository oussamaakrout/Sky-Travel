#include <gtk/gtk.h>


void
on_Valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Confirmer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_Modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);
