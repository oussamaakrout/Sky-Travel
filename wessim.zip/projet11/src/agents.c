

#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include"agents.h"
#include<gtk/gtk.h>

void ajouter_agent(agent a)

{
FILE *f;

f=fopen("agents.txt","a+");

{


fprintf(f,"%s %s %s %s %s %s %s %s \n",a.id,a.nom,a.prenom,a.date_de_naissance,a.cin,a.genre,a.telephone,a.email);


fclose(f);
}
}

enum 
{	ID,
	NOM,
	PRENOM,
	DATE_DE_NAISSANCE,
	CIN,
	GENRE,
	TELEPHONE,
	EMAIL,	
	COLUMNS
};


void afficher_agent(GtkWidget *treeview1)
{
 GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char id[20];
char nom[20];
char prenom[20];
char date_de_naissance[20];
char cin[30];
char genre[20];
char telephone[20];
char email[30]; 



store=NULL;
FILE *f;
store=gtk_tree_view_get_model(treeview1);
if (store==NULL)
{renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" id",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview1),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview1),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" prenom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview1),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" date_de_naissance",renderer, "text",DATE_DE_NAISSANCE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview1),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" cin",renderer, "text",CIN,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview1),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" genre",renderer, "text",GENRE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview1),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" telephone",renderer, "text",TELEPHONE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview1),column);
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes(" email",renderer, "text",EMAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(treeview1),column);
}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING,
G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);
f=fopen("agents.txt","r");
if(f==NULL)
{return;}
else
{f=fopen("agents.txt","a+");
	while(fscanf(f,"%s %s %s %s %s %s %s %s  \n",id,nom,prenom,date_de_naissance,cin,genre,telephone,email)!=EOF)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,ID,id,NOM,nom,PRENOM,prenom,DATE_DE_NAISSANCE,date_de_naissance,CIN,cin,GENRE,genre,TELEPHONE,telephone,EMAIL,email,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(treeview1), GTK_TREE_MODEL (store));
	g_object_unref (store);
	}
}


void
Supprimer_agent(char *f,char s[30])
{

    agent a;
  FILE* fichierIn=NULL; // On déclare un  premier pointeur sur une structure de type FILE et on l'initialise.
  FILE* fichierOut=NULL; // On déclare un deuxieme pointeur sur une structure de type FILE et on l'initialise.

 if ((fichierIn = fopen(f, "r")) == NULL) // Nous testons l'ouverture du fichier en paramètre si ca échoue, on affiche un msg d'erreur.
        printf("ERREUR: Verifiez le nom de fichier de lecture");

 if ((fichierOut = fopen("agents_copie.txt", "w")) == NULL) // nous testons l'ouverture du fichier dont on va copier si ca échoue, on affiche un msg d'erreur et on ferme le fichier dont on va lire (en paramètre)
    {
        fclose(fichierIn);
        printf("ERREUR: Verifiez le nom de fichier d'ecriture");
    }


while(!feof(fichierIn)){ // Tant qu'on n'a pas arrivé à la fin du fichier

      fscanf(fichierIn,"%s %s %s %s %s %s %s %s  \n",a.id,a.nom,a.prenom,a.date_de_naissance,a.cin,a.genre,a.telephone,a.email); // Récupérer les données du fichier les enregistré dans les champs correspondants
      if (strcmp(s,a.id)!=0) 
      {fprintf(fichierOut,"%s %s %s %s %s %s %s %s  \n",a.id,a.nom,a.prenom,a.date_de_naissance,a.cin,a.genre,a.telephone,a.email);} // ecrire les données dans le deuxieme fichier
      }

    fclose(fichierIn); //On ferme les fichiers
    fclose(fichierOut);

    remove(f); // on supprime le fichier passé en paramétre
    rename("agents_copie.txt", f); // on renome le deuxieme fichier
}
 

