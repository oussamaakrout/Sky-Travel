

#include <gtk/gtk.h>



typedef struct
{
char id[20];
char nom[20];
char prenom[20];
char date_de_naissance[20];
char cin[30];
char genre[20];
char telephone[20];
char email[30];

} agent;


void ajouter_agent(a);
void afficher_agent(GtkWidget *treeview1);
void Supprimer_vol(char *f,char s[30]);
