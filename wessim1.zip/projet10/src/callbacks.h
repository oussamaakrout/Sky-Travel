#include <gtk/gtk.h>


void
on_Connexion_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
