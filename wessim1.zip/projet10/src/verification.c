#include <stdio.h>
#include <string.h>
#include "verification.h"

int verification(char login[],char password[])
{
FILE *f;
char log[30];
char pass[30];
int role;
f=fopen("users.txt","r");
        if (f!=NULL)
{
             while(fscanf(f,"%s %s %d \n",login,password,&role)!=EOF)  
{
if ((strcmp(login,log)!=0)&&(strcmp(password,pass)!=0))
break;
else role=0;
}
}  
fclose(f);    
         
return(role);
     
 }
