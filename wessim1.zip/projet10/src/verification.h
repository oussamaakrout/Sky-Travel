#include <stdlib.h>
#include <string.h>



int verification(char login[],char password[]);
