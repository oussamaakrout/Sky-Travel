#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "verification.h"


void
on_Connexion_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *authentification;
GtkWidget *espace_admin;
GtkWidget *espace_agent;
GtkWidget *espace_client;
GtkWidget *input;
GtkWidget *input1;
GtkWidget *output;


FILE *f;
char login[30];
char password[30];
int a;
input=lookup_widget(objet,"login");
strcpy(login,gtk_entry_get_text(GTK_ENTRY(input)));
input1=lookup_widget(objet,"password");
strcpy(password,gtk_entry_get_text(GTK_ENTRY(input1)));
output=lookup_widget(objet,"label6");


a=verification(login,password);
switch (a)
{ case 1:
if (a==1)
{ authentification=lookup_widget(objet,"authentifiction");
espace_admin=lookup_widget(objet,"espace_admin");
gtk_widget_destroy(authentification);
espace_admin=create_espace_admin();
gtk_widget_show(espace_admin); }
break;
case 2:
  authentification=lookup_widget(objet,"authentification");
espace_agent=lookup_widget(objet,"espace_agent");
gtk_widget_destroy(authentification);
espace_agent=create_espace_agent();
gtk_widget_show(espace_agent);
break;
case 3:
  authentification=lookup_widget(objet,"authentification");
espace_client=lookup_widget(objet,"espace_client");
gtk_widget_destroy(authentification);
espace_client=create_espace_client();
gtk_widget_show(espace_client);
break; 
default:
gtk_label_set_text(GTK_LABEL(output),"vos donnees sont invalides!");
break;

}
}

